<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mat-label-login</name>
   <tag></tag>
   <elementGuidId>2f90a423-6bde-4de2-88d6-b683821ec14d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='GitHub'])[1]/following::mat-card-title[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>mat-card-title.mat-mdc-card-title.mat-h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>mat-card-title</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>mat-card-title</value>
      <webElementGuid>39b6e0b9-cdc7-48b6-9d85-0ebd753909f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-mdc-card-title mat-h1</value>
      <webElementGuid>89f9fb46-72cb-4bde-aa06-9c10176c3e3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Login </value>
      <webElementGuid>79bd9845-0ab0-42d9-a514-99ba276e9c1a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/div[@class=&quot;container&quot;]/app-login[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;d-flex justify-content-center&quot;]/mat-card[@class=&quot;mat-mdc-card mdc-card my-4 w-50&quot;]/mat-card-header[@class=&quot;mat-mdc-card-header mat-elevation-z2 custom-card-header justify-content-between&quot;]/div[@class=&quot;mat-mdc-card-header-text&quot;]/mat-card-title[@class=&quot;mat-mdc-card-title mat-h1&quot;]</value>
      <webElementGuid>7cf97ebc-c01e-4978-b633-617156647e06</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GitHub'])[1]/following::mat-card-title[1]</value>
      <webElementGuid>e5d318c9-60e6-4035-ad5c-c64425a378f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Swagger'])[1]/following::mat-card-title[1]</value>
      <webElementGuid>e5d49100-66cd-4886-aef9-da83757f5e61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New User?'])[1]/preceding::mat-card-title[1]</value>
      <webElementGuid>42ac072b-c192-4efc-8599-a1cb2a0e2c7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register'])[1]/preceding::mat-card-title[1]</value>
      <webElementGuid>28a53523-f1a6-4b05-bd3f-e62e0d17964f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-card-title</value>
      <webElementGuid>f1999f5f-cfd3-4783-a8fb-02aa0e1e41a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//mat-card-title[(text() = ' Login ' or . = ' Login ')]</value>
      <webElementGuid>0d6214b9-fb87-44ff-92d0-eeaacf19fe56</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
