<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mat-label-Book Details</name>
   <tag></tag>
   <elementGuidId>d208ae0f-2499-42e8-9e0f-e09ff846c356</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='GitHub'])[1]/following::mat-card-title[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>mat-card-title.mat-mdc-card-title.mat-h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Book Details&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>mat-card-title</value>
      <webElementGuid>e5f14f1d-770a-4aff-8d31-94277dd4a587</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-mdc-card-title mat-h1</value>
      <webElementGuid>de631e3d-0c31-49f8-b7ae-d7770c52a7ed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Book Details</value>
      <webElementGuid>a341580b-880c-40ec-9a82-3fbd85316daf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/div[@class=&quot;container&quot;]/app-book-details[@class=&quot;ng-star-inserted&quot;]/mat-card[@class=&quot;mat-mdc-card mdc-card mt-4 ng-star-inserted&quot;]/mat-card-header[@class=&quot;mat-mdc-card-header mat-elevation-z2 custom-card-header&quot;]/div[@class=&quot;mat-mdc-card-header-text&quot;]/mat-card-title[@class=&quot;mat-mdc-card-title mat-h1&quot;]</value>
      <webElementGuid>a2abb45e-6e1c-400c-bfb8-2381b2c78522</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GitHub'])[1]/following::mat-card-title[1]</value>
      <webElementGuid>3ddff78f-9b52-473c-9184-bf427941c367</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Swagger'])[1]/following::mat-card-title[1]</value>
      <webElementGuid>b786552e-2867-403f-aeba-3c7824338393</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Title'])[1]/preceding::mat-card-title[1]</value>
      <webElementGuid>1eb9d41d-a9d7-4559-bf75-c5632c03c215</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Harry Potter and the Chamber of Secrets'])[1]/preceding::mat-card-title[1]</value>
      <webElementGuid>46c21427-a4d5-4323-b903-e1b7837459db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-card-title</value>
      <webElementGuid>af17da74-1063-4e19-a6dc-b5d8db6ec7df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//mat-card-title[(text() = 'Book Details' or . = 'Book Details')]</value>
      <webElementGuid>72c1b713-4e6c-4888-8661-22856712e409</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
