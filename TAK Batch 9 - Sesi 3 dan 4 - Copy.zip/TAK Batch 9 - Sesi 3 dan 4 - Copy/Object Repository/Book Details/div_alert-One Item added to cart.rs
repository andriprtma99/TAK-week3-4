<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_alert-One Item added to cart</name>
   <tag></tag>
   <elementGuidId>3a0eb19f-b51d-4fee-9c9e-694c121d5484</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[(text() = ' One Item added to cart
' or . = ' One Item added to cart
')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value></value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e23fcc41-5a3e-4a2a-a9ce-52754e20a47f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-mdc-snack-bar-label mdc-snackbar__label</value>
      <webElementGuid>0d14163e-8b2f-4436-8e46-68bfb9526a73</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> One Item added to cart
</value>
      <webElementGuid>427b3a8a-6233-4c44-993e-8b7dffda70b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/simple-snack-bar[@class=&quot;mat-mdc-simple-snack-bar ng-star-inserted&quot;]/div[@class=&quot;mat-mdc-snack-bar-label mdc-snackbar__label&quot;]</value>
      <webElementGuid>986248e5-1ec6-4f00-8bf8-91683a17eaa5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' One Item added to cart
' or . = ' One Item added to cart
')]</value>
      <webElementGuid>e2ff52ea-f0c1-48c3-8611-d1ae459af93f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
