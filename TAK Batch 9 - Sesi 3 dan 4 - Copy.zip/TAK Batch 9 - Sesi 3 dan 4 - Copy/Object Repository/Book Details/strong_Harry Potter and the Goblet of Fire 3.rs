<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>strong_Harry Potter and the Goblet of Fire 3</name>
   <tag></tag>
   <elementGuidId>c81497ed-2daf-4515-85c1-7bff6e599c2a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Harry Potter and the Goblet of Fire' or . = 'Harry Potter and the Goblet of Fire')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='favorite'])[3]/following::strong[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>mat-card.mat-mdc-card.mdc-card.book-card.mat-elevation-z2.on-book-card-hover > mat-card-content.mat-mdc-card-content > div.card-title.my-2 > a > strong</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Harry Potter and the Goblet of Fire&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>strong</value>
      <webElementGuid>f0c57980-4733-492e-9959-9f9e67a8eb6a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Harry Potter and the Goblet of Fire</value>
      <webElementGuid>a82a61f9-fc38-41f2-be5a-b5e2bcf55bd5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/div[@class=&quot;container&quot;]/app-home[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;row no-gutters pt-3 ng-star-inserted&quot;]/div[@class=&quot;col mb-3&quot;]/div[@class=&quot;d-flex justify-content-start card-deck-container mb-4 ng-star-inserted&quot;]/div[@class=&quot;p-1 ng-star-inserted&quot;]/app-book-card[1]/mat-card[@class=&quot;mat-mdc-card mdc-card book-card mat-elevation-z2 on-book-card-hover&quot;]/mat-card-content[@class=&quot;mat-mdc-card-content&quot;]/div[@class=&quot;card-title my-2&quot;]/a[1]/strong[1]</value>
      <webElementGuid>29a9a767-e42b-42c2-9974-2876fcf25150</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='favorite'])[3]/following::strong[1]</value>
      <webElementGuid>db1a5004-98e8-4b0f-94ed-5f1890cf6bd4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to Cart'])[2]/following::strong[1]</value>
      <webElementGuid>0d7d8b28-ae7c-4245-aa0b-00bf8b73104e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add to Cart'])[3]/preceding::strong[1]</value>
      <webElementGuid>2c4c5765-f7c2-4bab-9440-518bc081041a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='favorite'])[4]/preceding::strong[1]</value>
      <webElementGuid>801f1232-7869-4064-b03a-e25116e9255b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Harry Potter and the Goblet of Fire']/parent::*</value>
      <webElementGuid>0066bbe1-aa97-4249-b3f9-926042a5a01d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/app-book-card/mat-card/mat-card-content/div[2]/a/strong</value>
      <webElementGuid>8dce3a38-796b-4209-a342-fcc3f8e12364</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//strong[(text() = 'Harry Potter and the Goblet of Fire' or . = 'Harry Potter and the Goblet of Fire')]</value>
      <webElementGuid>84d1b02d-8564-4ab2-b2ef-94b1194c3000</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
