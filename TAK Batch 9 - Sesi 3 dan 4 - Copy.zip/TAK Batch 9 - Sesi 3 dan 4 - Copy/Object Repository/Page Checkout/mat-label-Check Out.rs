<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mat-label-Check Out</name>
   <tag></tag>
   <elementGuidId>296abed3-9dae-4d4c-a2ce-f5d2c9954d48</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='GitHub'])[1]/following::mat-card-title[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>mat-card-title.mat-mdc-card-title.mat-h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Check Out&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>mat-card-title</value>
      <webElementGuid>32648d08-4df7-4a73-bdde-5e572d4279ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-mdc-card-title mat-h1</value>
      <webElementGuid>28cef7b3-627c-49e3-ae3b-1d0d4a948113</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Check Out </value>
      <webElementGuid>5f1a5912-a9d9-4533-8d28-1e7310aacfbc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/div[@class=&quot;container&quot;]/app-checkout[@class=&quot;ng-star-inserted&quot;]/mat-card[@class=&quot;mat-mdc-card mdc-card my-4 ng-star-inserted&quot;]/mat-card-header[@class=&quot;mat-mdc-card-header custom-card-header mat-elevation-z2&quot;]/div[@class=&quot;mat-mdc-card-header-text&quot;]/mat-card-title[@class=&quot;mat-mdc-card-title mat-h1&quot;]</value>
      <webElementGuid>c91df21e-a928-4f4e-8398-c87684181f06</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GitHub'])[1]/following::mat-card-title[1]</value>
      <webElementGuid>18defc9b-8e1e-4914-bd25-fcec1dfb2f1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Swagger'])[1]/following::mat-card-title[1]</value>
      <webElementGuid>d47616fc-acef-41a9-8f66-8b6dd5d3d487</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shipping address'])[1]/preceding::mat-card-title[1]</value>
      <webElementGuid>5a75e944-bc22-4ef1-ae4d-5a21c0b233df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name'])[1]/preceding::mat-card-title[2]</value>
      <webElementGuid>cc7ffdb9-d94f-4fa2-9b81-419bd2a61fe3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Check Out']/parent::*</value>
      <webElementGuid>01669625-b3ce-4762-9ba3-c860bf6744a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-card-title</value>
      <webElementGuid>d000a34b-56c3-4961-bc01-3a62ae87d85f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//mat-card-title[(text() = 'Check Out ' or . = 'Check Out ')]</value>
      <webElementGuid>3a76e6e2-f802-48e6-808d-6b15321b1dff</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
