<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>th_label-Order Id</name>
   <tag></tag>
   <elementGuidId>b4afc492-0c71-412e-85f5-db9c10657c03</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::th[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>th.mat-mdc-header-cell.mdc-data-table__header-cell.cdk-header-cell.cdk-column-orderId.mat-column-orderId.ng-tns-c259219554-12.ng-star-inserted.mat-mdc-table-sticky.mat-mdc-table-sticky-border-elem-top</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=columnheader[name=&quot;Order Id&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
      <webElementGuid>3b52315e-cb95-4b18-92a8-f92badba8832</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>columnheader</value>
      <webElementGuid>24264705-779f-4c4e-9efc-3caa6302b6d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-mdc-header-cell mdc-data-table__header-cell cdk-header-cell cdk-column-orderId mat-column-orderId ng-tns-c259219554-12 ng-star-inserted mat-mdc-table-sticky mat-mdc-table-sticky-border-elem-top</value>
      <webElementGuid>bec9d2ce-3b66-46ea-821b-045aea4c107b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Order Id</value>
      <webElementGuid>9bb52979-3c5b-443b-b0c6-07670017e0c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/div[@class=&quot;container&quot;]/app-my-orders[@class=&quot;ng-tns-c259219554-12 ng-star-inserted&quot;]/mat-card[@class=&quot;mat-mdc-card mdc-card my-4 ng-tns-c259219554-12 ng-star-inserted&quot;]/div[@class=&quot;ng-tns-c259219554-12 ng-star-inserted&quot;]/mat-card-content[@class=&quot;mat-mdc-card-content ng-tns-c259219554-12&quot;]/div[@class=&quot;mat-elevation-z2 ng-tns-c259219554-12&quot;]/table[@class=&quot;mat-mdc-table mdc-data-table__table cdk-table ng-tns-c259219554-12&quot;]/thead[@class=&quot;ng-star-inserted&quot;]/tr[@class=&quot;mat-mdc-header-row mdc-data-table__header-row cdk-header-row ng-tns-c259219554-12 ng-star-inserted&quot;]/th[@class=&quot;mat-mdc-header-cell mdc-data-table__header-cell cdk-header-cell cdk-column-orderId mat-column-orderId ng-tns-c259219554-12 ng-star-inserted mat-mdc-table-sticky mat-mdc-table-sticky-border-elem-top&quot;]</value>
      <webElementGuid>ad934fca-610c-4f86-a0ba-e10915c58e57</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::th[1]</value>
      <webElementGuid>c2fc2bcb-6eb9-4634-8224-caa92c0f0613</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Orders'])[1]/following::th[1]</value>
      <webElementGuid>e2a2ed3b-d461-4c35-b09e-8962babebeb5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ordered On'])[1]/preceding::th[1]</value>
      <webElementGuid>4577d336-87af-4b6a-861e-4377ca1a08a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Total'])[1]/preceding::th[2]</value>
      <webElementGuid>1b9ce33b-32c9-4e43-92bb-1dfb66f6f779</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Order Id']/parent::*</value>
      <webElementGuid>d9435686-0ac2-4af9-b07b-7e1208bfedd7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th</value>
      <webElementGuid>bbd4c0d3-908a-4025-ad45-f8692c2c835c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//th[(text() = 'Order Id' or . = 'Order Id')]</value>
      <webElementGuid>7ea8d0d8-43e0-40ac-9aff-2f9da2df3654</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
