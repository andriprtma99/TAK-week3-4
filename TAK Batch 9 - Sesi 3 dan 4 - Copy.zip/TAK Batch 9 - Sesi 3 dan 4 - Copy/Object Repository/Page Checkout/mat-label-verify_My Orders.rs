<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mat-label-verify_My Orders</name>
   <tag></tag>
   <elementGuidId>a9907efe-c476-4003-b5d1-adba4a0a9b86</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='GitHub'])[1]/following::mat-card-title[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>mat-card-title.mat-mdc-card-title.mat-h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;My Orders&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>mat-card-title</value>
      <webElementGuid>f7e32138-03e0-4a6f-b744-b44df0d502f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-mdc-card-title mat-h1</value>
      <webElementGuid>3c8aeb40-a50a-4ed9-aaf4-dbea54d664e4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>My Orders </value>
      <webElementGuid>0516a044-ddb9-4453-bd1b-fc9ea0371026</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/div[@class=&quot;container&quot;]/app-my-orders[@class=&quot;ng-tns-c259219554-12 ng-star-inserted&quot;]/mat-card[@class=&quot;mat-mdc-card mdc-card my-4 ng-tns-c259219554-12 ng-star-inserted&quot;]/mat-card-header[@class=&quot;mat-mdc-card-header custom-card-header mat-elevation-z2&quot;]/div[@class=&quot;mat-mdc-card-header-text&quot;]/mat-card-title[@class=&quot;mat-mdc-card-title mat-h1&quot;]</value>
      <webElementGuid>655ac858-f94f-4a08-8f7d-e365e8d2e1d6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='GitHub'])[1]/following::mat-card-title[1]</value>
      <webElementGuid>05f67e08-265d-4389-95b6-f4a632748720</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Swagger'])[1]/following::mat-card-title[1]</value>
      <webElementGuid>04344233-ed8e-4ff2-ac14-9523fc80ee9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/preceding::mat-card-title[1]</value>
      <webElementGuid>99c2227d-1bd4-478b-abe4-b1f287f513d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Id'])[1]/preceding::mat-card-title[1]</value>
      <webElementGuid>c1657da0-c964-4141-b578-9e76319f219a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='My Orders']/parent::*</value>
      <webElementGuid>1d6d31cd-bfff-43dc-8d67-9f40418143cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//mat-card-title</value>
      <webElementGuid>922b9aac-8e27-410b-94f5-806add1a6636</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//mat-card-title[(text() = 'My Orders ' or . = 'My Orders ')]</value>
      <webElementGuid>99fe3471-e8bb-4372-8f31-7eb794ef7d76</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
