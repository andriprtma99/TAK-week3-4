<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>th_label-Order Total</name>
   <tag></tag>
   <elementGuidId>c9ce0be7-dccb-44b7-b9ba-6aa94eaae3d4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Ordered On'])[1]/following::th[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>th.mat-mdc-header-cell.mdc-data-table__header-cell.cdk-header-cell.cdk-column-cartTotal.mat-column-cartTotal.ng-tns-c259219554-12.ng-star-inserted.mat-mdc-table-sticky.mat-mdc-table-sticky-border-elem-top</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=columnheader[name=&quot;Order Total&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
      <webElementGuid>a62efb60-6afe-4b7c-86a0-195cba75c2b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>columnheader</value>
      <webElementGuid>ca0a6df6-9517-4b5a-b770-d297e6d07cff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-mdc-header-cell mdc-data-table__header-cell cdk-header-cell cdk-column-cartTotal mat-column-cartTotal ng-tns-c259219554-12 ng-star-inserted mat-mdc-table-sticky mat-mdc-table-sticky-border-elem-top</value>
      <webElementGuid>4d97ab66-d1cf-455d-b281-5342ef9b9a75</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Order Total</value>
      <webElementGuid>46b94a44-8ecc-4daa-bbf4-67a320881b85</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/div[@class=&quot;container&quot;]/app-my-orders[@class=&quot;ng-tns-c259219554-12 ng-star-inserted&quot;]/mat-card[@class=&quot;mat-mdc-card mdc-card my-4 ng-tns-c259219554-12 ng-star-inserted&quot;]/div[@class=&quot;ng-tns-c259219554-12 ng-star-inserted&quot;]/mat-card-content[@class=&quot;mat-mdc-card-content ng-tns-c259219554-12&quot;]/div[@class=&quot;mat-elevation-z2 ng-tns-c259219554-12&quot;]/table[@class=&quot;mat-mdc-table mdc-data-table__table cdk-table ng-tns-c259219554-12&quot;]/thead[@class=&quot;ng-star-inserted&quot;]/tr[@class=&quot;mat-mdc-header-row mdc-data-table__header-row cdk-header-row ng-tns-c259219554-12 ng-star-inserted&quot;]/th[@class=&quot;mat-mdc-header-cell mdc-data-table__header-cell cdk-header-cell cdk-column-cartTotal mat-column-cartTotal ng-tns-c259219554-12 ng-star-inserted mat-mdc-table-sticky mat-mdc-table-sticky-border-elem-top&quot;]</value>
      <webElementGuid>35dd41cc-8bd1-4e30-ae4b-fe57311e185b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ordered On'])[1]/following::th[1]</value>
      <webElementGuid>8059c479-5db1-4b52-8116-3214d251e03f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Id'])[1]/following::th[2]</value>
      <webElementGuid>fe234616-fe27-4cdf-aa14-04685087d2eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feb 25, 2025'])[1]/preceding::th[1]</value>
      <webElementGuid>297fd7b0-98ad-4f26-a5e6-2f6d16c53798</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='₹669.00'])[1]/preceding::th[1]</value>
      <webElementGuid>1a4b434f-f3a9-4a94-897d-17d5437d347a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Order Total']/parent::*</value>
      <webElementGuid>8a56fd51-7f61-4ffc-ba84-5e9f95c29279</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[3]</value>
      <webElementGuid>bb83845a-6494-4648-a3a1-fdff998d7550</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//th[(text() = 'Order Total' or . = 'Order Total')]</value>
      <webElementGuid>d5b8b989-48f9-46e4-ba69-a0e283a1155f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
