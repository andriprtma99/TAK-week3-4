<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>th_label-Ordered On</name>
   <tag></tag>
   <elementGuidId>7dd661cc-0450-47c9-9c03-9e072c8716ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Id'])[1]/following::th[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>th.mat-mdc-header-cell.mdc-data-table__header-cell.cdk-header-cell.cdk-column-orderDate.mat-column-orderDate.ng-tns-c259219554-12.ng-star-inserted.mat-mdc-table-sticky.mat-mdc-table-sticky-border-elem-top</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=columnheader[name=&quot;Ordered On&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>th</value>
      <webElementGuid>c0063e83-7280-450b-b9f6-3c7a3d122862</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>columnheader</value>
      <webElementGuid>6fd18bf9-8555-4c71-b7ac-c2d502743781</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-mdc-header-cell mdc-data-table__header-cell cdk-header-cell cdk-column-orderDate mat-column-orderDate ng-tns-c259219554-12 ng-star-inserted mat-mdc-table-sticky mat-mdc-table-sticky-border-elem-top</value>
      <webElementGuid>4cc0734b-c008-4384-9a9f-b0829570b6a0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Ordered On</value>
      <webElementGuid>ae1e6b89-e158-483b-a523-2abe69ebf4c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/div[@class=&quot;container&quot;]/app-my-orders[@class=&quot;ng-tns-c259219554-12 ng-star-inserted&quot;]/mat-card[@class=&quot;mat-mdc-card mdc-card my-4 ng-tns-c259219554-12 ng-star-inserted&quot;]/div[@class=&quot;ng-tns-c259219554-12 ng-star-inserted&quot;]/mat-card-content[@class=&quot;mat-mdc-card-content ng-tns-c259219554-12&quot;]/div[@class=&quot;mat-elevation-z2 ng-tns-c259219554-12&quot;]/table[@class=&quot;mat-mdc-table mdc-data-table__table cdk-table ng-tns-c259219554-12&quot;]/thead[@class=&quot;ng-star-inserted&quot;]/tr[@class=&quot;mat-mdc-header-row mdc-data-table__header-row cdk-header-row ng-tns-c259219554-12 ng-star-inserted&quot;]/th[@class=&quot;mat-mdc-header-cell mdc-data-table__header-cell cdk-header-cell cdk-column-orderDate mat-column-orderDate ng-tns-c259219554-12 ng-star-inserted mat-mdc-table-sticky mat-mdc-table-sticky-border-elem-top&quot;]</value>
      <webElementGuid>e3d8a03a-cf7e-492c-9720-90127c9e4d82</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Id'])[1]/following::th[1]</value>
      <webElementGuid>4f6f1afe-4f0f-4a4a-aab9-08820126edd5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::th[2]</value>
      <webElementGuid>65aeddcb-acb4-44c5-b341-efd0262d1847</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order Total'])[1]/preceding::th[1]</value>
      <webElementGuid>0371d291-e222-42d9-b9ad-508487556abe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feb 25, 2025'])[1]/preceding::th[2]</value>
      <webElementGuid>91f00255-fc99-43c3-821d-f21731f276ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Ordered On']/parent::*</value>
      <webElementGuid>94c6b1ad-9ab8-41b2-8864-50446af46c7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//th[2]</value>
      <webElementGuid>e746c380-7f2f-4446-87c5-1accb5c5198e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//th[(text() = 'Ordered On' or . = 'Ordered On')]</value>
      <webElementGuid>5630e5ea-ab08-4e1a-8b62-97488dbbf977</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
