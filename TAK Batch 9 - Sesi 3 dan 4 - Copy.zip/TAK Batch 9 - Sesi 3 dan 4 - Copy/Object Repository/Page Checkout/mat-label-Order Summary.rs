<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mat-label-Order Summary</name>
   <tag></tag>
   <elementGuidId>430c9c20-c783-41f1-8b7d-c7e07db2eb38</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::mat-card-title[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>mat-card-title.mat-mdc-card-title.ng-star-inserted</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Order Summary&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>mat-card-title</value>
      <webElementGuid>14a2ef29-ad4d-4823-89d7-efe04c813060</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mat-mdc-card-title ng-star-inserted</value>
      <webElementGuid>070c7117-96f0-4cea-9062-106113eb6baf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Order Summary </value>
      <webElementGuid>de516879-9296-49ef-a9f7-98b847089d5b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/div[@class=&quot;container&quot;]/app-checkout[@class=&quot;ng-star-inserted&quot;]/mat-card[@class=&quot;mat-mdc-card mdc-card my-4 ng-star-inserted&quot;]/mat-card-content[@class=&quot;mat-mdc-card-content p-2&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6&quot;]/mat-card-title[@class=&quot;mat-mdc-card-title ng-star-inserted&quot;]</value>
      <webElementGuid>ddfee9a2-a072-4c4f-8a0e-9972b726a73e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::mat-card-title[1]</value>
      <webElementGuid>dfc5997c-d716-4bcb-95dc-966b73627e59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Place Order'])[1]/following::mat-card-title[1]</value>
      <webElementGuid>55388721-cdd9-4b86-a229-b7989cd9899e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Title'])[1]/preceding::mat-card-title[1]</value>
      <webElementGuid>ba3709bb-1c71-4920-ae1e-eccb3703552d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quantity'])[1]/preceding::mat-card-title[1]</value>
      <webElementGuid>d1b1b64c-2729-4afc-b97c-e7dc5d55ed3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Order Summary']/parent::*</value>
      <webElementGuid>157d7bbf-701b-4c93-8484-ca94d0e4ffe4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/mat-card-title</value>
      <webElementGuid>c9f8869c-7143-4077-9007-bd563bd726ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//mat-card-title[(text() = ' Order Summary ' or . = ' Order Summary ')]</value>
      <webElementGuid>23a61d14-979a-4d04-bb9b-fec76e9d4a3d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
